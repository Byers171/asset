import urllib.request
import json

url = 'http://localhost:8080/api/asset-category/fix-encoding'
headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMzgwMDAwMDAwMCIsImlhdCI6MTczNzk4NjA1MCwiZXhwIjoxNzM4MDcyNDUwfQ.abc123'
}

try:
    req = urllib.request.Request(url, data=json.dumps({}).encode('utf-8'), headers=headers, method='POST')
    with urllib.request.urlopen(req) as response:
        print('Status Code:', response.status)
        print('Response:', response.read().decode('utf-8'))
except Exception as e:
    print('Error:', str(e))