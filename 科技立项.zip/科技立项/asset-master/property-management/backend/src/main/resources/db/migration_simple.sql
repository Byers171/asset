-- 数据迁移脚本（简化版）
-- 目标：确保资产分类数据与现有资产信息的迁移工作

-- 1. 创建资产分类表
CREATE TABLE IF NOT EXISTS pm_asset_category (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    category_code VARCHAR(50),
    category_name VARCHAR(100) NOT NULL,
    parent_id BIGINT,
    level INT,
    asset_type VARCHAR(50) NOT NULL,
    description TEXT,
    sort_order INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'active',
    deleted INT DEFAULT 0,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. 插入初始资产分类数据
-- 固定资产分类
INSERT IGNORE INTO pm_asset_category (category_code, category_name, parent_id, level, asset_type, description, sort_order, status) VALUES
('FA001', '房屋建筑物', NULL, 1, 'fixed', '企业拥有的房屋、建筑物等', 1, 'active'),
('FA00101', '办公楼', 1, 2, 'fixed', '企业办公使用的建筑物', 1, 'active'),
('FA00102', '厂房', 1, 2, 'fixed', '企业生产使用的建筑物', 2, 'active'),
('FA002', '机器设备', NULL, 1, 'fixed', '企业生产经营使用的机器设备', 2, 'active'),
('FA00201', '生产设备', 4, 2, 'fixed', '直接用于生产的设备', 1, 'active'),
('FA00202', '办公设备', 4, 2, 'fixed', '办公使用的设备', 2, 'active'),
('FA003', '交通工具', NULL, 1, 'fixed', '企业使用的交通工具', 3, 'active'),
('FA00301', '汽车', 7, 2, 'fixed', '企业拥有的汽车', 1, 'active'),
('FA00302', '其他交通工具', 7, 2, 'fixed', '其他类型的交通工具', 2, 'active');

-- 流动资产分类
INSERT IGNORE INTO pm_asset_category (category_code, category_name, parent_id, level, asset_type, description, sort_order, status) VALUES
('CA001', '原材料', NULL, 1, 'current', '生产用原材料', 1, 'active'),
('CA00101', '主要材料', 10, 2, 'current', '生产主要使用的材料', 1, 'active'),
('CA00102', '辅助材料', 10, 2, 'current', '生产辅助使用的材料', 2, 'active'),
('CA002', '低值易耗品', NULL, 1, 'current', '价值较低的易耗品', 2, 'active'),
('CA00201', '办公用品', 13, 2, 'current', '办公使用的易耗品', 1, 'active'),
('CA00202', '生产工具', 13, 2, 'current', '生产使用的工具', 2, 'active'),
('CA003', '库存商品', NULL, 1, 'current', '企业库存的商品', 3, 'active'),
('CA00301', '成品', 16, 2, 'current', '已完成生产的成品', 1, 'active'),
('CA00302', '半成品', 16, 2, 'current', '未完成生产的半成品', 2, 'active');

-- 3. 数据迁移：更新现有资产的分类信息
UPDATE pm_asset SET 
    category_id = CASE 
        WHEN asset_type = 'fixed' THEN 1
        WHEN asset_type = 'current' THEN 10
        ELSE 1
    END,
    category_name = CASE 
        WHEN asset_type = 'fixed' THEN 'Buildings'
        WHEN asset_type = 'current' THEN 'Materials'
        ELSE 'Buildings'
    END
WHERE category_id IS NULL OR category_id = 0;

-- 4. 数据迁移：设置默认资产类型
UPDATE pm_asset SET asset_type = 'fixed' WHERE asset_type IS NULL OR asset_type = '';

-- 5. 数据迁移：设置固定资产和流动资产的默认值
UPDATE pm_asset SET 
    depreciation_method = 'straight_line',
    expected_life = 10,
    residual_value = 0
WHERE asset_type = 'fixed' AND (depreciation_method IS NULL OR depreciation_method = '');

UPDATE pm_asset SET 
    supplier = 'Unknown',
    warranty_period = '1 year',
    unit = 'pcs',
    quantity = 1
WHERE asset_type = 'current' AND (supplier IS NULL OR supplier = '');

-- 6. 生成迁移报告
SELECT 
    'Asset Type Distribution' as report_type,
    asset_type as category,
    COUNT(*) as count
FROM pm_asset
GROUP BY asset_type
UNION ALL
SELECT 
    'Category Distribution' as report_type,
    category_name as category,
    COUNT(*) as count
FROM pm_asset
GROUP BY category_name
ORDER BY report_type, count DESC;

-- 7. 验证数据完整性
SELECT 
    'Data Integrity Check' as check_type,
    COUNT(*) as total_assets,
    SUM(CASE WHEN asset_type IS NOT NULL AND asset_type != '' THEN 1 ELSE 0 END) as assets_with_type,
    SUM(CASE WHEN category_id IS NOT NULL AND category_id > 0 THEN 1 ELSE 0 END) as assets_with_category
FROM pm_asset;