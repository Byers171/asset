-- 数据迁移脚本
-- 目标：确保资产分类数据与现有资产信息的迁移工作

-- 1. 检查并创建资产分类表（如果不存在）
CREATE TABLE IF NOT EXISTS pm_asset_category (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '主键ID',
    category_code VARCHAR(50) COMMENT '分类编码',
    category_name VARCHAR(100) NOT NULL COMMENT '分类名称',
    parent_id BIGINT COMMENT '父分类ID',
    level INT COMMENT '分类级别：1-一级, 2-二级, 3-三级',
    asset_type VARCHAR(50) NOT NULL COMMENT '资产类型：fixed-固定资产, current-流动资产',
    description TEXT COMMENT '分类描述',
    sort_order INT DEFAULT 0 COMMENT '排序顺序',
    status VARCHAR(20) DEFAULT 'active' COMMENT '状态：active-启用, inactive-禁用',
    deleted INT DEFAULT 0 COMMENT '删除标记',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='资产分类表';

-- 2. 检查并修改资产表（如果需要）
-- 创建存储过程来添加列（如果不存在）
DELIMITER //
DROP PROCEDURE IF EXISTS add_column_if_not_exists //
CREATE PROCEDURE add_column_if_not_exists(
    IN table_name VARCHAR(255),
    IN column_name VARCHAR(255),
    IN column_definition TEXT
)
BEGIN
    DECLARE column_exists INT;
    
    SELECT COUNT(*) INTO column_exists
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = table_name
    AND COLUMN_NAME = column_name;
    
    IF column_exists = 0 THEN
        SET @sql = CONCAT('ALTER TABLE ', table_name, ' ADD COLUMN ', column_name, ' ', column_definition);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //
DELIMITER ;

-- 添加资产类型字段（如果不存在）
CALL add_column_if_not_exists('pm_asset', 'asset_type', "VARCHAR(50) NOT NULL DEFAULT 'fixed' COMMENT '资产类型：fixed-固定资产, current-流动资产'");
-- 添加分类ID字段（如果不存在）
CALL add_column_if_not_exists('pm_asset', 'category_id', "BIGINT COMMENT '分类ID'");
-- 添加固定资产特有字段（如果不存在）
CALL add_column_if_not_exists('pm_asset', 'depreciation_method', "VARCHAR(50) COMMENT '折旧方法：straight_line-直线法, accelerated-加速折旧'");
CALL add_column_if_not_exists('pm_asset', 'expected_life', "INT COMMENT '预计使用年限(年)'");
CALL add_column_if_not_exists('pm_asset', 'residual_value', "DECIMAL(15,2) COMMENT '残值'");
-- 添加流动资产特有字段（如果不存在）
CALL add_column_if_not_exists('pm_asset', 'supplier', "VARCHAR(100) COMMENT '供应商'");
CALL add_column_if_not_exists('pm_asset', 'warranty_period', "VARCHAR(50) COMMENT '质保期'");
CALL add_column_if_not_exists('pm_asset', 'unit', "VARCHAR(20) COMMENT '单位'");
CALL add_column_if_not_exists('pm_asset', 'quantity', "INT COMMENT '数量'");

-- 删除临时存储过程
DROP PROCEDURE IF EXISTS add_column_if_not_exists;

-- 3. 插入初始资产分类数据（如果不存在）
-- 固定资产分类
INSERT IGNORE INTO pm_asset_category (category_code, category_name, parent_id, level, asset_type, description, sort_order, status) VALUES
('FA001', '房屋建筑物', NULL, 1, 'fixed', '企业拥有的房屋、建筑物等', 1, 'active'),
('FA00101', '办公楼', 1, 2, 'fixed', '企业办公使用的建筑物', 1, 'active'),
('FA00102', '厂房', 1, 2, 'fixed', '企业生产使用的建筑物', 2, 'active'),
('FA002', '机器设备', NULL, 1, 'fixed', '企业生产经营使用的机器设备', 2, 'active'),
('FA00201', '生产设备', 4, 2, 'fixed', '直接用于生产的设备', 1, 'active'),
('FA00202', '办公设备', 4, 2, 'fixed', '办公使用的设备', 2, 'active'),
('FA003', '交通工具', NULL, 1, 'fixed', '企业使用的交通工具', 3, 'active'),
('FA00301', '汽车', 7, 2, 'fixed', '企业拥有的汽车', 1, 'active'),
('FA00302', '其他交通工具', 7, 2, 'fixed', '其他类型的交通工具', 2, 'active');

-- 流动资产分类
INSERT IGNORE INTO pm_asset_category (category_code, category_name, parent_id, level, asset_type, description, sort_order, status) VALUES
('CA001', '原材料', NULL, 1, 'current', '生产用原材料', 1, 'active'),
('CA00101', '主要材料', 10, 2, 'current', '生产主要使用的材料', 1, 'active'),
('CA00102', '辅助材料', 10, 2, 'current', '生产辅助使用的材料', 2, 'active'),
('CA002', '低值易耗品', NULL, 1, 'current', '价值较低的易耗品', 2, 'active'),
('CA00201', '办公用品', 13, 2, 'current', '办公使用的易耗品', 1, 'active'),
('CA00202', '生产工具', 13, 2, 'current', '生产使用的工具', 2, 'active'),
('CA003', '库存商品', NULL, 1, 'current', '企业库存的商品', 3, 'active'),
('CA00301', '成品', 16, 2, 'current', '已完成生产的成品', 1, 'active'),
('CA00302', '半成品', 16, 2, 'current', '未完成生产的半成品', 2, 'active');

-- 4. 数据迁移：更新现有资产的分类信息
-- 假设现有资产没有分类信息，我们需要根据资产类型分配默认分类
UPDATE pm_asset SET 
    category_id = CASE 
        WHEN asset_type = 'fixed' THEN 1 -- 默认为房屋建筑物
        WHEN asset_type = 'current' THEN 10 -- 默认为原材料
        ELSE 1
    END,
    category_name = CASE 
        WHEN asset_type = 'fixed' THEN '房屋建筑物'
        WHEN asset_type = 'current' THEN '原材料'
        ELSE '房屋建筑物'
    END
WHERE category_id IS NULL OR category_id = 0;

-- 5. 数据迁移：设置默认资产类型（如果未设置）
UPDATE pm_asset SET asset_type = 'fixed' WHERE asset_type IS NULL OR asset_type = '';

-- 6. 数据迁移：设置固定资产和流动资产的默认值
-- 固定资产默认值
UPDATE pm_asset SET 
    depreciation_method = 'straight_line',
    expected_life = 10,
    residual_value = 0
WHERE asset_type = 'fixed' AND (depreciation_method IS NULL OR depreciation_method = '');

-- 流动资产默认值
UPDATE pm_asset SET 
    supplier = '未知供应商',
    warranty_period = '1年',
    unit = '个',
    quantity = 1
WHERE asset_type = 'current' AND (supplier IS NULL OR supplier = '');

-- 7. 生成迁移报告
SELECT 
    '资产类型分布' as report_type,
    asset_type as category,
    COUNT(*) as count
FROM pm_asset
GROUP BY asset_type
UNION ALL
SELECT 
    '分类分布' as report_type,
    category_name as category,
    COUNT(*) as count
FROM pm_asset
GROUP BY category_name
ORDER BY report_type, count DESC;

-- 8. 验证数据完整性
SELECT 
    '数据完整性检查' as check_type,
    COUNT(*) as total_assets,
    SUM(CASE WHEN asset_type IS NOT NULL AND asset_type != '' THEN 1 ELSE 0 END) as assets_with_type,
    SUM(CASE WHEN category_id IS NOT NULL AND category_id > 0 THEN 1 ELSE 0 END) as assets_with_category
FROM pm_asset;