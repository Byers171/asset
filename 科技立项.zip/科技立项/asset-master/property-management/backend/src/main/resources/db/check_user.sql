-- 查找用户名为13800000000的用户
SELECT id, username, phone, user_type FROM pm_user WHERE phone = '13800000000' OR username = '13800000000';