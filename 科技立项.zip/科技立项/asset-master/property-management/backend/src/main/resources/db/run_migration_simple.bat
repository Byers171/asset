@echo off
mysql -u root -p1234 property_management < migration_simple.sql
echo Simple Migration completed!
pause