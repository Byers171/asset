-- 检查现有资产表结构
DESCRIBE pm_asset;