-- 添加缺失的字段到资产表
ALTER TABLE pm_asset ADD COLUMN category_id BIGINT;
ALTER TABLE pm_asset ADD COLUMN category_name VARCHAR(100);
ALTER TABLE pm_asset ADD COLUMN depreciation_method VARCHAR(50);
ALTER TABLE pm_asset ADD COLUMN expected_life INT;
ALTER TABLE pm_asset ADD COLUMN residual_value DECIMAL(15,2);
ALTER TABLE pm_asset ADD COLUMN supplier VARCHAR(100);
ALTER TABLE pm_asset ADD COLUMN warranty_period VARCHAR(50);
ALTER TABLE pm_asset ADD COLUMN unit VARCHAR(20);
ALTER TABLE pm_asset ADD COLUMN quantity INT;