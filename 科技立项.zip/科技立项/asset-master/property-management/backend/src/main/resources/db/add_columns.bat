@echo off
mysql -u root -p1234 property_management < add_columns.sql
echo Columns added successfully!
pause