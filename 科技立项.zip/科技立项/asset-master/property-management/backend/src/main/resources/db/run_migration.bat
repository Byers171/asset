@echo off
mysql -u root -p1234 property_management < migration.sql
echo Migration completed!
pause