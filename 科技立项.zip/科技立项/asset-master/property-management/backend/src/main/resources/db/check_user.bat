@echo off
mysql -u root -p1234 property_management < check_user.sql
pause